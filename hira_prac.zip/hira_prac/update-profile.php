<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hira_prac";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch current user data
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM hira_prac_table WHERE user_id = '$user_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>✏️ Update Profile</h2>

        <?php if(isset($_GET['success'])): ?>
            <p style="color: #11998e; text-align: center; margin-bottom: 15px; font-weight: 500;">✅ Profile updated successfully!</p>
        <?php endif; ?>

        <?php if(isset($_GET['error'])): ?>
            <p style="color: #f44336; text-align: center; margin-bottom: 15px; font-weight: 500;">❌ Update failed! Please try again.</p>
        <?php endif; ?>

        <form action="update-profile-process.php" method="POST">
            <div class="form-group">
                <label for="first_name">First Name</label>
                <input id="first_name" name="first_name" required type="text" value="<?php echo htmlspecialchars($user['first_name']); ?>" placeholder="Enter your first name"/>
            </div>

            <div class="form-group">
                <label for="last_name">Last Name</label>
                <input id="last_name" name="last_name" required type="text" value="<?php echo htmlspecialchars($user['last_name']); ?>" placeholder="Enter your last name"/>
            </div>

            <div class="form-group">
                <label>Gender</label>
                <div class="radio-group">
                    <label class="radio-option">
                        <input name="gender" required type="radio" value="male" <?php echo ($user['gender'] == 'male') ? 'checked' : ''; ?>/>
                        <span>Male</span>
                    </label>
                    <label class="radio-option">
                        <input name="gender" required type="radio" value="female" <?php echo ($user['gender'] == 'female') ? 'checked' : ''; ?>/>
                        <span>Female</span>
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" required placeholder="Enter your address"><?php echo htmlspecialchars($user['address']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input id="email" name="email" required type="email" value="<?php echo htmlspecialchars($user['email']); ?>" placeholder="your.email@example.com"/>
            </div>

            <div class="form-group">
                <label for="PASSWORD">Password (Leave blank to keep current)</label>
                <input id="PASSWORD" name="PASSWORD" type="password" placeholder="Enter new password (optional)"/>
            </div>

            <button type="submit" class="submit-btn">Update Profile</button>
        </form>

        <p style="text-align: center; margin-top: 20px;">
            <a href="dashboard.php" style="color: #667eea; text-decoration: none;">← Back to Dashboard</a>
        </p>
    </div>
</body>
</html>
