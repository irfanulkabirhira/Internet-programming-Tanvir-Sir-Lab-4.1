<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hira_prac";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect and sanitize form data
$user_id = $_SESSION['user_id'];
$first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
$last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
$gender = mysqli_real_escape_string($conn, $_POST['gender']);
$address = mysqli_real_escape_string($conn, $_POST['address']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$PASSWORD = mysqli_real_escape_string($conn, $_POST['PASSWORD']);

// Build update query
if (!empty($PASSWORD)) {
    // Update with new password
    $sql = "UPDATE hira_prac_table SET
            first_name = '$first_name',
            last_name = '$last_name',
            gender = '$gender',
            address = '$address',
            email = '$email',
            PASSWORD = '$PASSWORD'
            WHERE user_id = '$user_id'";
} else {
    // Update without changing password
    $sql = "UPDATE hira_prac_table SET
            first_name = '$first_name',
            last_name = '$last_name',
            gender = '$gender',
            address = '$address',
            email = '$email'
            WHERE user_id = '$user_id'";
}

if ($conn->query($sql) === TRUE) {
    // Update session variables
    $_SESSION['first_name'] = $first_name;
    $_SESSION['last_name'] = $last_name;
    $_SESSION['email'] = $email;

    // Redirect with success message
    header("Location: dashboard.php");
    // header("Location: update-profile.php?success=1");
    exit();
} else {
    // Redirect with error message
    header("Location: update-profile.php?error=1");
    exit();
}

$conn->close();
?>