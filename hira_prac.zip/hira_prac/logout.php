<?php
session_start();

// Store user name before destroying session
$first_name = isset($_SESSION['first_name']) ? $_SESSION['first_name'] : 'User';

// Destroy all session data
session_unset();
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logged Out</title>
    <link rel="stylesheet" href="style_logout.css">
    <meta http-equiv="refresh" content="3;url=login.php">
</head>
<body>
    <div class="container">
        <div class="logout-icon">👋</div>
        <h1>Goodbye, <?php echo htmlspecialchars($first_name); ?>!</h1>
        <p class="message">You have been successfully logged out</p>

        <div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>

        <p class="redirect-text">Redirecting to login page in 3 seconds...</p>

        <div class="action-buttons">
            <a href="login.php" class="btn btn-primary">Login Again</a>
            <a href="index.php" class="btn btn-secondary">Register</a>
        </div>
    </div>
</body>
</html>