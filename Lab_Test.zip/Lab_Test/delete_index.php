<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lab_test";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login_index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete user from database
$sql = "DELETE FROM lab_test_table WHERE user_id = '$user_id'";

if ($conn->query($sql) === TRUE) {

    // Destroy session after deletion
    session_unset();
    session_destroy();

    // Redirect to register page
    header("Location: Register_index.php");
    exit();

} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
