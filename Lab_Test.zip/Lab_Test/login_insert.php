<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lab_test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect and sanitize form data
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

// Query to check if user exists
$sql = "SELECT * FROM lab_test_table WHERE email = '$email' AND password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Login successful
    $row = $result->fetch_assoc();

    // Store user data in session
    $_SESSION['user_id'] = $row['user_id'];
    $_SESSION['email'] = $row['email'];
    $_SESSION['first_name'] = $row['first_name'];
    $_SESSION['last_name'] = $row['last_name'];

    echo "Login successful! Welcome " . $row['first_name'] . " " . $row['last_name'];

    
    // Redirect to dashboard or home page
    header("Location: dashboard_index.php");
    // exit();
} else {
    // Login failed
    echo "Invalid email or password. Please try again.";

    // Redirect back to login page
    header("Location: login_index.php?error=1");
    exit();
}

// Close the connection
$conn->close();
?>