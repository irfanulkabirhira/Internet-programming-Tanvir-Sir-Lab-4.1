<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="Style_login.css">
</head>
<body>
    <div class="container">
        <h2>🔐 Login</h2>
        <form action="login_insert.php" method="POST">
            <div class="form-group">
                <label for="email">Email</label>
                <input id="email" name="email" required type="email" placeholder="Enter your email"/>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input id="password" name="password" required type="password" placeholder="Enter your password"/>
            </div>

            <button type="submit" class="submit-btn">Login</button>
        </form>

        <div class="footer-links">
            <a href="#">Forgot Password?</a>
            <span class="separator">|</span>
            <a href="Register_index.php">Create Account</a>
        </div>
    </div>
</body>
</html>