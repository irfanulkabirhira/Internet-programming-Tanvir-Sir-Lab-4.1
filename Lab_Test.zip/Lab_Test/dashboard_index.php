    <?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login_index.php");
    exit();
}

$first_name = $_SESSION['first_name'];
$last_name = $_SESSION['last_name'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style_dashboard.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎉 Welcome Back!</h1>
            <p class="subtitle">You're successfully logged in</p>
        </div>

        <div class="user-card">
            <div class="avatar">
                <?php echo strtoupper(substr($first_name, 0, 1) . substr($last_name, 0, 1)); ?>
            </div>
            <div class="user-info">
                <h2><?php echo $first_name . " " . $last_name; ?></h2>
                <p class="email"><?php echo $email; ?></p>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <h3>Dashboard</h3>
                <p>View your analytics</p>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⚙️</div>
                <h3>Settings</h3>
                <p>Manage your account</p>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📧</div>
                <h3>Messages</h3>
                <p>Check your inbox</p>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📈</div>
                <h3>Reports</h3>
                <p>View statistics</p>
            </div>
        </div>



        <div class="action-buttons">
            <a href="update_profile_index.php" class="btn btn-primary">Update Profile</a>
            <a href="logout_index.php" class="btn btn-logout">Logout</a>
            <a href="delete_index.php" onclick="return confirm('Are you sure you want to delete your profile?');" class="btn btn-delete">Delete Profile</a>
        </div>
    </div>
</body>
</html>