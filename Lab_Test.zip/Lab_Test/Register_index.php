<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="Style_Register.css">
</head>
<body>
    <div class="container">
        <h2>📝 Registration Form</h2>
        <form action="Register_insert.php" method="POST">
            <div class="form-group">
                <label for="first_name">First Name</label>
                <input id="first_name" name="first_name" required type="text" placeholder="Enter your first name"/>
            </div>

            <div class="form-group">
                <label for="last_name">Last Name</label>
                <input id="last_name" name="last_name" required type="text" placeholder="Enter your last name"/>
            </div>

            <div class="form-group">
                <label>Gender</label>
                <div class="radio-group">
                    <label class="radio-option">
                        <input name="gender" required type="radio" value="male"/>
                        <span>Male</span>
                    </label>
                    <label class="radio-option">
                        <input name="gender" required type="radio" value="female"/>
                        <span>Female</span>
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" required placeholder="Enter your address"></textarea>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input id="email" name="email" required type="email" placeholder="your.email@example.com"/>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input id="password" name="password" required type="password" placeholder="Enter your Password"/>
            </div>

            <button type="submit" class="submit-btn">Submit Form</button>
        </form>
        
        <p>Already Registered ?? <a href="login_index.php">Login</a></p>
    </div>
</body>
</html>