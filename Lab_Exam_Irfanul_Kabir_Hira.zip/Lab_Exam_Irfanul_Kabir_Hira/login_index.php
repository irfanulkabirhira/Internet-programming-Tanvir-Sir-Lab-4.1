<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Login</title>
  <link rel="stylesheet" href="Style_Login.css">
</head>
<body>

<div class="container">
  <h2>🔐 Student Login</h2>

  <form action="login_insert.php" method="POST">
    <div class="form-group">
      <label>Email</label>
      <input type="email" name="email" required>
    </div>

    <div class="form-group">
      <label>Password</label>
      <input type="password" name="password" required>
    </div>

    <button type="submit" class="submit-btn">Login</button>
  </form>

  <?php
  if (isset($_GET['error'])) {
      echo "<p class='error-msg'>❌ Invalid Email or Password</p>";
  }
  ?>

  <p class="bottom-link">New user? <a href="register_index.php">Register</a></p>
</div>

</body>
</html>