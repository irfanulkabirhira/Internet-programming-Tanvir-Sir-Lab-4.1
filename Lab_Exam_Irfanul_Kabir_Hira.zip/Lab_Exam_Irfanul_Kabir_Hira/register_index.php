<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link rel="stylesheet" href="Style_Register.css">
</head>
<body>

<div class="container">
    <h2>📝 Student Registration</h2>

    <form action="register_insert.php" method="POST" onsubmit="return validatePassword();">

        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" required>
        </div>

        <div class="form-group">
            <label>Student ID</label>
            <input type="text" name="student_id" required>
        </div>

        <div class="form-group">
            <label>Department</label>
            <input type="text" name="department" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" required>
        </div>

        <div class="form-group">
            <label>Mobile Number</label>
            <input type="text" name="mobile" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" id="password" name="password" required>
        </div>

        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>

        <div class="rules">
            <p><b>Password Rules:</b></p>
            <ul>
                <li>Minimum 8 characters</li>
                <li>At least 1 uppercase letter</li>
                <li>At least 1 lowercase letter</li>
                <li>At least 1 digit</li>
                <li>At least 1 special character</li>
                <li>Confirm password must match</li>
            </ul>
        </div>

        <button type="submit" class="submit-btn">Register</button>
    </form>

    <?php
    if (isset($_GET['error'])) {
        echo "<p class='error-msg'>❌ " . htmlspecialchars($_GET['error']) . "</p>";
    }
    if (isset($_GET['success'])) {
        echo "<p class='success-msg'>✅ Registration Successful! Now Login.</p>";
    }
    ?>

    <p class="bottom-link">Already have account? <a href="login_index.php">Login</a></p>
</div>

<script>
function validatePassword() {
    // password input nicchi ami 
    const pass = document.getElementById("password").value;
    const confirm = document.getElementById("confirm_password").value;

    const minLen = pass.length >= 8;
    const upper = /[A-Z]/.test(pass);
    const lower = /[a-z]/.test(pass);
    const digit = /[0-9]/.test(pass);
    const special = /[^A-Za-z0-9]/.test(pass);
    const match = pass === confirm;

    if (!minLen || !upper || !lower || !digit || !special) {
        alert("Password must follow all rules (8+ length, upper, lower, digit, special).");
        return false;
    }
    if (!match) {
        alert("Confirm password does not match!");
        return false;
    }
    return true;
}
</script>

</body>
</html>