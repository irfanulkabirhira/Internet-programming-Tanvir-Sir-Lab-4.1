<?php
session_start();
require "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login_index.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];

$res = $conn->query("SELECT full_name, student_id, department, email, mobile, created_at
                     FROM students WHERE user_id = $user_id");

if (!$res || $res->num_rows === 0) {
    header("Location: dashboard_index.php");
    exit();
}

$user = $res->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile</title>
  <link rel="stylesheet" href="Style_Profile.css">
</head>
<body>

<div class="container">
  <h2>👤 My Profile</h2>

  <table>
    <tr><th>Full Name</th><td><?= htmlspecialchars($user['full_name']) ?></td></tr>
    <tr><th>Student ID</th><td><?= htmlspecialchars($user['student_id']) ?></td></tr>
    <tr><th>Department</th><td><?= htmlspecialchars($user['department']) ?></td></tr>
    <tr><th>Email</th><td><?= htmlspecialchars($user['email']) ?></td></tr>
    <tr><th>Mobile</th><td><?= htmlspecialchars($user['mobile']) ?></td></tr>
    <tr><th>Registered At</th><td><?= htmlspecialchars($user['created_at']) ?></td></tr>
  </table>

  <div class="btn-group">
    <a class="btn" href="dashboard_index.php">← Back</a>
    <a class="btn danger" href="logout_index.php">Logout</a>
  </div>
</div>

</body>
</html>