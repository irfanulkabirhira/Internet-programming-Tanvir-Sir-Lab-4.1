<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_portal_lab";

$conn = new mysqli($servername, $username, $password, $dbname);


# Kono error ki correction er time e hoice kina sheta mean kore !!
# jodi hoi tahole --> Empty otherwise show korbe error message


if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>