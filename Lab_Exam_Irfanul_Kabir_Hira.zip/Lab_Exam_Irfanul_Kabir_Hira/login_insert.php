<?php
session_start();
require "db.php";

$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

$stmt = $conn->prepare("SELECT user_id, email, password_hash FROM students WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();


//  jodi  email na thake num_row = 0
//  jodi email thake num_row = 1

//  1 rhakchi reason amr result obvisuly 1 hote hobe
if ($res && $res->num_rows === 1) {
    $user = $res->fetch_assoc();

    if (password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['email'] = $user['email'];
        header("Location: dashboard_index.php");
        exit();
    }
}

header("Location: login_index.php?error=1");
exit();
?>