<?php
require "db.php";

function valid_password($p) {
    if (strlen($p) < 8) return false;
    if (!preg_match("/[A-Z]/", $p)) return false;
    if (!preg_match("/[a-z]/", $p)) return false;
    if (!preg_match("/[0-9]/", $p)) return false;
    if (!preg_match("/[^A-Za-z0-9]/", $p)) return false;
    return true;
}

# Data nicchi form theke
$full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
$student_id = mysqli_real_escape_string($conn, $_POST['student_id']);
$department = mysqli_real_escape_string($conn, $_POST['department']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

if ($password !== $confirm_password) {
    header("Location: register_index.php?error=Confirm%20password%20does%20not%20match");
    exit();
}

if (!valid_password($password)) {
    header("Location: register_index.php?error=Password%20rules%20not%20matched");
    exit();
}


//  ekhane ami ask korteci Stuedent Id and Emial agge theke ache kina

/* UNIQUE CHECK */
$check = $conn->query("SELECT user_id FROM students
    WHERE student_id='$student_id' OR email='$email' OR mobile='$mobile'");

if ($check && $check->num_rows > 0) {
    header("Location: register_index.php?error=StudentID%20or%20Email%20or%20Mobile%20already%20exists");
    exit();
}


//  password directly Database a save korteci nah --> ami hash kore save korteci
// karon jodi Database hack hoi thle password keu jante parbe nah

/* HASH PASSWORD */
$hash = password_hash($password, PASSWORD_DEFAULT);


// Student table a new etka row add korteci 

/* INSERT */
$sql = "INSERT INTO students (full_name, student_id, department, email, mobile, password_hash)
        VALUES ('$full_name','$student_id','$department','$email','$mobile','$hash')";

if ($conn->query($sql) === TRUE) {
    header("Location: register_index.php?success=1");
    exit();
} else {
    header("Location: register_index.php?error=Database%20insert%20failed");
    exit();
}
?>