<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login_index.php");
    exit();
}

$email = $_SESSION['email'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <link rel="stylesheet" href="Style_Dashboard.css">
</head>
<body>

<div class="container">
  <h2>✅ Login Successful</h2>
  <p class="subtitle">Welcome: <?php echo htmlspecialchars($email); ?></p>

  <div class="btn-group">
    <a class="btn" href="profile_index.php">👤 Profile</a>
    <a class="btn danger" href="logout_index.php">🚪 Logout</a>
  </div>
</div>

</body>
</html>