<?php
session_start();

/* ===== PROTECT DASHBOARD ===== */
if (!isset($_SESSION['admin_email'])) {
    header("Location: login_index.php");
    exit();
}

$admin_email = $_SESSION['admin_email'];

/* ===== DATABASE CONNECTION (FIXED) ===== */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lab_test_A2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

/* ===== FETCH STUDENTS ===== */
$query = "SELECT * FROM student_registration ORDER BY user_id DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style_dashboard.css">
</head>
<body>

<div class="container">

    <!-- Header -->
    <div class="header">
        <h1>Admin Dashboard</h1>
        <p class="subtitle">Registered Students</p>
    </div>

    <!-- Admin Info -->
    <div class="user-card">
        <div class="avatar">A</div>
        <div class="user-info">
            <h2>Admin</h2>
            <p class="email"><?php echo htmlspecialchars($admin_email); ?></p>
        </div>
    </div>

    <!-- Student Table -->
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Roll</th>
                    <th>Phone</th>
                    <th>Division</th>
                    <th>Gender</th>
                    <th>Result</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result->num_rows > 0) { ?>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= $row['user_id']; ?></td>
                        <td><?= htmlspecialchars($row['full_name']); ?></td>
                        <td><?= htmlspecialchars($row['roll']); ?></td>
                        <td><?= htmlspecialchars($row['phone']); ?></td>
                        <td><?= htmlspecialchars($row['division']); ?></td>
                        <td><?= htmlspecialchars($row['gender']); ?></td>
                        <td><?= htmlspecialchars($row['result']); ?></td>
                        <td class="action">
                            <a href="update_profile_index.php?id=<?= $row['user_id']; ?>" class="btn-update">Update</a>
                            <a href="delete_index.php?id=<?= $row['user_id']; ?>"
                               class="btn-delete"
                               onclick="return confirm('Are you sure you want to delete this student?');">
                               Delete
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <tr>
                    <td colspan="8" class="no-data">No students found</td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Logout -->
    <div class="logout">
        <a href="logout_index.php" class="btn-logout">Logout</a>
    </div>

</div>

</body>
</html>

<?php $conn->close(); ?>
