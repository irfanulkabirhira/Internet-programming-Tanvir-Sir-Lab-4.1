<?php
session_start();

/* ===== ADMIN PROTECTION ===== */
if (!isset($_SESSION['admin_email'])) {
    header("Location: login_index.php");
    exit();
}

/* ===== DB CONNECTION ===== */
$conn = new mysqli("localhost", "root", "", "lab_test_A2");
if ($conn->connect_error) {
    die("Database Connection Failed");
}

/* ===== RECEIVE DATA ===== */
$user_id     = $_POST['user_id'];
$full_name   = mysqli_real_escape_string($conn, $_POST['full_name']);
$roll        = mysqli_real_escape_string($conn, $_POST['roll']);
$phone       = mysqli_real_escape_string($conn, $_POST['phone']);
$father_name = mysqli_real_escape_string($conn, $_POST['father_name']);
$mother_name = mysqli_real_escape_string($conn, $_POST['mother_name']);
$division    = mysqli_real_escape_string($conn, $_POST['division']);
$result      = mysqli_real_escape_string($conn, $_POST['result']);
$gender      = mysqli_real_escape_string($conn, $_POST['gender']);

/* ===== UPDATE QUERY ===== */
$sql = "UPDATE student_registration SET
        full_name='$full_name',
        roll='$roll',
        phone='$phone',
        father_name='$father_name',
        mother_name='$mother_name',
        division='$division',
        result='$result',
        gender='$gender'
        WHERE user_id='$user_id'";

if ($conn->query($sql) === TRUE) {
    header("Location: dashboard_index.php");
    exit();
} else {
    echo "Update Error: " . $conn->error;
}

$conn->close();
?>
