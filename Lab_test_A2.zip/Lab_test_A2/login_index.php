<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="Style_login.css">
</head>
<body>

<div class="container">
    <h2>🔐 Admin Login</h2>

    <form action="login_insert.php" method="POST">
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="admin@gmail.com" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="123456" required>
        </div>

        <button type="submit" class="submit-btn">Login</button>
    </form>

    <?php
    if (isset($_GET['error'])) {
        echo "<p class='error-msg'>❌ Invalid Email or Password</p>";
    }
    ?>

    <div class="footer-links">
        <a href="Register_index.php">Go to Registration</a>
    </div>
</div>

</body>
</html>
