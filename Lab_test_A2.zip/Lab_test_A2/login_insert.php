<?php
session_start();

/* ===== STATIC ADMIN CREDENTIALS ===== */
$static_email = "admin@gmail.com";
$static_password = "123456";

/* ===== USER INPUT ===== */
$email = $_POST['email'];
$password = $_POST['password'];

/* ===== LOGIN CHECK ===== */
if ($email === $static_email && $password === $static_password) {

    $_SESSION['admin_email'] = $static_email;

    // Successful login
    header("Location: dashboard_index.php");
    exit();

} else {
    // Failed login
    header("Location: login_index.php?error=1");
    exit();
}
?>
