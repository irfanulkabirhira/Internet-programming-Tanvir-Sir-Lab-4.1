<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Registration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style_Register.css">
</head>
<body>

<div class="container">
    <h2>Student Registration</h2>

    <form action="Register_insert.php" method="POST">

        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" required>
        </div>

        <div class="form-group">
            <label>Roll (Unique)</label>
            <input type="text" name="roll" required>
        </div>

        <div class="form-group">
            <label>Phone (Unique)</label>
            <input type="text" name="phone" required>
        </div>

        <div class="form-group">
            <label>Father's Name</label>
            <input type="text" name="father_name" required>
        </div>

        <div class="form-group">
            <label>Mother's Name</label>
            <input type="text" name="mother_name" required>
        </div>

        <div class="form-group">
            <label>Division</label>
            <select name="division" required>
                <option value="">-- Select Division --</option>
                <option value="Dhaka">Dhaka</option>
                <option value="Chattogram">Chattogram</option>
                <option value="Rajshahi">Rajshahi</option>
                <option value="Khulna">Khulna</option>
                <option value="Barishal">Barishal</option>
                <option value="Sylhet">Sylhet</option>
                <option value="Rangpur">Rangpur</option>
                <option value="Mymensingh">Mymensingh</option>
            </select>
        </div>

        <div class="form-group">
            <label>Result</label>
            <input type="text" name="result" required>
        </div>

        <div class="form-group">
            <label>Gender</label>
            <div class="radio-group">
                <label class="radio-option">
                    <input type="radio" name="gender" value="Male" required>
                    <span>Male</span>
                </label>
                <label class="radio-option">
                    <input type="radio" name="gender" value="Female">
                    <span>Female</span>
                </label>
                <label class="radio-option">
                    <input type="radio" name="gender" value="Other">
                    <span>Other</span>
                </label>
            </div>
        </div>

        <button type="submit" class="submit-btn">Register</button>
    </form>
    <p>Already Registered ?? <a href="login_index.php">Login</a></p>

</div>
</body>
</html>
