<?php
session_start();

/* ===== ADMIN PROTECTION ===== */
if (!isset($_SESSION['admin_email'])) {
    header("Location: login_index.php");
    exit();
}

/* ===== CHECK ID ===== */
if (!isset($_GET['id'])) {
    header("Location: dashboard_index.php");
    exit();
}

$user_id = $_GET['id'];

/* ===== DB CONNECTION ===== */
$conn = new mysqli("localhost", "root", "", "lab_test_A2");
if ($conn->connect_error) {
    die("Database Connection Failed");
}

/* ===== FETCH STUDENT ===== */
$sql = "SELECT * FROM student_registration WHERE user_id='$user_id'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    header("Location: dashboard_index.php");
    exit();
}

$student = $result->fetch_assoc();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Student</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style_Register.css">
</head>
<body>

<div class="container">
    <h2>✏️ Update Student</h2>

    <form action="update_profile_insert.php" method="POST">

        <input type="hidden" name="user_id" value="<?= $student['user_id']; ?>">

        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name"
                   value="<?= htmlspecialchars($student['full_name']); ?>" required>
        </div>

        <div class="form-group">
            <label>Roll</label>
            <input type="text" name="roll"
                   value="<?= htmlspecialchars($student['roll']); ?>" required>
        </div>

        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone"
                   value="<?= htmlspecialchars($student['phone']); ?>" required>
        </div>

        <div class="form-group">
            <label>Father's Name</label>
            <input type="text" name="father_name"
                   value="<?= htmlspecialchars($student['father_name']); ?>" required>
        </div>

        <div class="form-group">
            <label>Mother's Name</label>
            <input type="text" name="mother_name"
                   value="<?= htmlspecialchars($student['mother_name']); ?>" required>
        </div>

        <div class="form-group">
            <label>Division</label>
            <select name="division" required>
                <?php
                $divisions = ["Dhaka","Chattogram","Rajshahi","Khulna","Barishal","Sylhet","Rangpur","Mymensingh"];
                foreach ($divisions as $d) {
                    $selected = ($student['division'] == $d) ? "selected" : "";
                    echo "<option value='$d' $selected>$d</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label>Result</label>
            <input type="text" name="result"
                   value="<?= htmlspecialchars($student['result']); ?>" required>
        </div>

        <div class="form-group">
            <label>Gender</label>
            <div class="radio-group">
                <?php
                $genders = ["Male","Female","Other"];
                foreach ($genders as $g) {
                    $checked = ($student['gender'] == $g) ? "checked" : "";
                    echo "
                    <label class='radio-option'>
                        <input type='radio' name='gender' value='$g' $checked required>
                        <span>$g</span>
                    </label>";
                }
                ?>
            </div>
        </div>

        <button type="submit" class="submit-btn">Update Student</button>
    </form>

    <p style="text-align:center;margin-top:20px;">
        <a href="dashboard_index.php">← Back to Dashboard</a>
    </p>
</div>

</body>
</html>
