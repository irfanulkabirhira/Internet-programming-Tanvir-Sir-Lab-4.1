<?php
session_start();

/* ===== ADMIN PROTECTION ===== */
if (!isset($_SESSION['admin_email'])) {
    header("Location: login_index.php");
    exit();
}

/* ===== CHECK ID ===== */
if (!isset($_GET['id'])) {
    header("Location: dashboard_index.php");
    exit();
}

$user_id = $_GET['id'];

/* ===== DATABASE CONNECTION ===== */
$conn = new mysqli("localhost", "root", "", "lab_test_A2");

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

/* ===== DELETE QUERY ===== */
$sql = "DELETE FROM student_registration WHERE user_id = '$user_id'";

if ($conn->query($sql) === TRUE) {
    // Successful delete
    header("Location: dashboard_index.php");
    exit();
} else {
    echo "Delete Error: " . $conn->error;
}

$conn->close();
?>
