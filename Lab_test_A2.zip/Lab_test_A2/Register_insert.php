<?php
// ===== DATABASE CONNECTION =====
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "lab_test_A2";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ===== SANITIZE INPUT =====
$full_name   = mysqli_real_escape_string($conn, $_POST['full_name']);
$roll        = mysqli_real_escape_string($conn, $_POST['roll']);
$phone       = mysqli_real_escape_string($conn, $_POST['phone']);
$father_name = mysqli_real_escape_string($conn, $_POST['father_name']);
$mother_name = mysqli_real_escape_string($conn, $_POST['mother_name']);
$division    = mysqli_real_escape_string($conn, $_POST['division']);
$result      = mysqli_real_escape_string($conn, $_POST['result']);
$gender      = mysqli_real_escape_string($conn, $_POST['gender']);

// ===== CHECK FOR UNIQUE ROLL OR PHONE =====
$check_sql    = "SELECT * FROM student_registration WHERE roll='$roll' OR phone='$phone'";
$check_result = $conn->query($check_sql);

if ($check_result->num_rows > 0) {
    // Alert if duplicate found
    echo "<script>
            alert('Roll or Phone already exists! Please use unique values.');
            window.location.href='Register_index.php';
          </script>";
    exit();
}

// ===== INSERT DATA IF UNIQUE =====
$sql = "INSERT INTO student_registration
        (full_name, roll, phone, father_name, mother_name, division, result, gender)
        VALUES
        ('$full_name', '$roll', '$phone', '$father_name', '$mother_name', '$division', '$result', '$gender')";

if ($conn->query($sql) === TRUE) {
    echo "<script>
            alert('Registration Successful');
            window.location.href='Register_index.php';
          </script>";
} else {
    echo "<script>
            alert('Error: " . $conn->error . "');
            window.location.href='Register_index.php';
          </script>";
}

$conn->close();
?>
